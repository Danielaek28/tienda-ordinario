<?php
session_start();

if(isset($_POST['producto']) && isset($_POST['precio'])) {
    
    $_SESSION['carrito'][] = ["producto" => $_POST['producto'], "precio" => $_POST['precio']];
}


$compras = isset($_SESSION['carrito']) ? $_SESSION['carrito'] : [];

?>

<!DOCTYPE html>
<html lang="es">
<head>
    
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Carrito de Compra</h1>
        <nav>
            <a href="index.php">Inicio</a>
            <a href="ticket.php">Finalizar Compra</a>
        </nav>
    </header>

    <div class="carrito-container">
        <?php foreach($compras as $compra): ?>
            <div class="compra">
                <h2><?php echo $compra['producto']; ?></h2>
                <p>Precio: $<?php echo $compra['precio']; ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    
    <form action="vaciar_carrito.php" method="post">
    <button type="submit" name="vaciar">Vaciar Carrito</button>
    
</form>
</body>

</html>

