<?php
session_start();

$compras = isset($_SESSION['carrito']) ? $_SESSION['carrito'] : [];
$total = 0;

?>

 <!DOCTYPE html>
<html lang="es">
<head>
    
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Ticket de Compra</h1>
        <nav>
            <a href="index.php">Inicio</a>
            
        </nav>
    </header>
    <h2>Datos del cliente</h2>
    <?php
    if (isset($_COOKIE['nombre'])) {
    $nombre = $_COOKIE['nombre'];
    echo "<h4> Nombre:$nombre<h4>";
    $email = $_COOKIE['email'];
     echo "<h4> Correo: $email<h4>";

} else {
    echo "No hay datos del cliente registrados.";
}
?>   
    <div class="ticket-container">
        <h2>Detalle de compra</h2>
        
        <ul>
            <?php foreach($compras as $compra): ?>
    
                <li><?php echo $compra['producto']; ?> - Precio: $<?php echo $compra['precio']; ?></li>
                <?php $total += $compra['precio']; ?>
            <?php endforeach; ?>
        </ul>
        <p>Total a pagar: $<?php echo $total; ?></p>
    </div>
</body>
</html>


