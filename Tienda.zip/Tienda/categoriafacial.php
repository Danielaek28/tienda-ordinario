<!DOCTYPE html>
<html lang="es">
<head>

    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Facial</h1>
        <h1>Limpieza diaria para tu piel</h1>

        <nav>
             <a href="index.php">Inicio</a>
            <a href="registro.php">Registrarse</a>
            <a href="carrito.php">Carrito</a>
        </nav>
    </header>

    <div class="dproductos">
            <div class="producto">
            <img src="imagenes/espuma.jpg"width="100" height="100" />
            <h2>Espuma Limpiadora Facial</h2>
            <p>la espuma limpiadora facial SEYTÚ es ideal para una limpieza profunda.</p>
            <p>Precio: $345</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Espuma Limpiadora Facial">
                <input type="hidden" name="precio" value="345">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            
            <div class="producto">
            <img src="imagenes/exfoliante.jpg"width="100" height="100" />
            <h2>Exfoliante Facial con Extracto de Ginseng</h2>
            <p>El exfoliante facial con extracto de ginseng acondiciona y suaviza tu piel, dándote una apariencia fresca y tersa.</p>
            <p>Precio: $345</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Exfoliante Facial con Extracto de Ginseng">
                <input type="hidden" name="precio" value="345">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            
            <div class="producto">
            <img src="imagenes/mascarilla.jpg"width="100" height="100" />
            <h2>Mascarilla Facial</h2>
            <p>Fórmula de limpieza profunda que promueve la eliminación de las células muertas. Colabora en el proceso de regeneración en tu piel.</p>
            <p>Precio: $360</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Mascarilla Facial">
                <input type="hidden" name="precio" value="360">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            
            <div class="producto">
            <img src="imagenes/omniplus.jpg"width="100" height="100" />
            <h2>Omniplus Gel Premium</h2>
            <p>Omniplus gel premium colabora a mantener la piel protegida de los ataques de los radicales libres y aumentar el nivel de hidratación.</p>
            <p>Precio: $305</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Omniplus Gel Premium">
                <input type="hidden" name="precio" value="305">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            
            <div class="producto">
            <img src="imagenes/noche.jpg"width="100" height="100" />
            <h2>Crema Hidratante de Noche</h2>
            <p>Crema de uso nocturno, formulada para mejorar los niveles de hidratación y vitalidad en la piel, actuando en el momento en que la piel es más receptiva y su capacidad de auto reparación es más óptima. Despertarás con una piel visiblemente más hidratada y renovada.</p>
            <p>Precio: $420</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Crema Hidratante de Noche">
                <input type="hidden" name="precio" value="420">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            
            <div class="producto">
            <img src="imagenes/dia.jpg"width="100" height="100" />
            <h2>Crema de Día FPS 30</h2>
            <p>Combate los principales signos de la edad, estimulando la producción de colágeno, elastina y manteniendo la hidratación óptima de la piel. Brinda protección ante los rayos UVA y UVB. Se recomienda utilizar el sistema completo para lograr mejores resultados.</p>
            <p>Precio: $690</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Crema de Día FPS 30">
                <input type="hidden" name="precio" value="690">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
        
            <div class="producto">
            <img src="imagenes/contorno.jpg"width="100" height="100" />
            <h2>Crema para Contorno de Ojos</h2>
            <p>Cuida y mejora la apariencia de líneas finas y arrugas en la delicada zona del contorno de ojos, contribuye a reducir la apariencia de las bolsas y ojeras logrando una mirada revitalizada. Se recomienda utilizar el sistema completo para lograr mejores resultados.</p>
            <p>Precio: $420</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Crema para Contorno de Ojos">
                <input type="hidden" name="precio" value="420">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            
            <div class="producto">
            <img src="imagenes/fmanchas.jpg"width="100" height="100" />
            <h2>Gel Anti-Manchas</h2>
            <p>Formulado con activos aclarantes que ayudan a disminuir progresivamente las manchas producidas por envejecimiento, daño solar y marcas de acné.</p>
            <p>Precio: $540</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Gel Anti-Manchas">
                <input type="hidden" name="precio" value="540">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            <div class="producto">
            <img src="imagenes/fprotector.jpg"width="100" height="100" />
            <h2>Protector Solar Facial FPS 50 +</h2>
            <p>Protector solar facial con FPS 50+, ideal para pieles sensibles, toque seco, resistente al agua y libre de fragancia. Completa tu rutina facial y protege tu rostro.</p>
            <p>Precio: $350</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Protector Solar Facial FPS 50 +">
                <input type="hidden" name="precio" value="350">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            <div class="producto">
            <img src="imagenes/suero.jpg"width="100" height="100" />
            <h2>Suero Facial de Hidratación Profunda con Aloe Vera</h2>
            <p>El Suero Facial de Hidratación Profunda con Aloe Vera SEYTÚ, hidrata a profundidad y contribuye a la firmeza y elasticidad de tu piel.</p>
            <p>Precio: $400</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Suero Facial de Hidratación Profunda con Aloe Vera">
                <input type="hidden" name="precio" value="400">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            <div class="producto">
            <img src="imagenes/nsuero.jpg"width="100" height="100" />
            <h2>Suero de Noche</h2>
            <p>Contribuye a mejorar el aspecto de cansancio e hinchazón, actuando durante la noche y revelando una apariencia renovada por la mañana, disminuyendo los signos de la edad.</p>
            <p>Precio: $750</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Suero de Noche">
                <input type="hidden" name="precio" value="750">
                <button type="submit">agregar al carrito</button>
            </form>    
           
            </div>
            <div class="producto">
            <img src="imagenes/tonico.jpg"width="100" height="100" />
            <h2>Tónico Hidratante</h2>
            <p>Es ideal para regresar a la piel su balance de hidratación natural.</p>
            <p>Precio: $500</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Tónico Hidratante">
                <input type="hidden" name="precio" value="500">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
    </div>
</body>
</html>