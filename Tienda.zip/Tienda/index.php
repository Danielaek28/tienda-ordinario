<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Bienvenido</title>
</head>
<body>
<header>
       
        <?php
if (isset($_COOKIE['nombre'])) {
    $nombre = $_COOKIE['nombre'];
    echo "<h1>Bienvenido, $nombre</h1>";
} else {
    echo "<h1>Bienvenido</h1>";
}
?>
        <h1>SÉ TU Y BRILLA</h1>
        <nav>
            <a href="registro.php">Registrarse</a>
        </nav>
    </header>
    <div class="categorias">
    <br5> <p>Por favor, elige una categoría</p><br5>
    <ul>
    <a href="categoriafacial.php?categoria=facial"><img src="imagenes/facial.jpg" alt="Facial"></a>
     <a href="categoriacapilar.php?categoria=Capilar"><img src="imagenes/capilar.jpg" alt="Capilar"></a>
    <a href="categoriafragancia.php?categoria=fragancia"><img src="imagenes/fragancia.jpg" alt="Fragancia"></a>
    <a href="categoriamaquillaje.php?categoria=maquillaje"><img src="imagenes/maquillaje.jpg" alt="Maquillaje"></a>
    <a href="categoriacorporal.php?categoria=corporal"><img src="imagenes/corporal.jpg" alt="Corporal"></a>
    </ul>
    </div>
</body>
</html>



