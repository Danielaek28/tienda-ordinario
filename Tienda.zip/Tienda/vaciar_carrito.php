<?php
session_start();


if(isset($_POST['vaciar'])) {
    
    unset($_SESSION['carrito']);
    
   
    header("Location: index.php");
    exit();
} else {
    
    header("Location: carrito.php");
    exit();
}
?>
