<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Maquillaje</h1>
        <h1>Brilla de dia y de noche</h1>

        <nav>
             <a href="index.php">Inicio</a>
            <a href="registro.php">Registrarse</a>
            <a href="carrito.php">Carrito</a>
        </nav>
    </header>
    
    <div class="dproductos">
            <div class="producto">
            <img src="imagenes/polvo.jpg"width="100" height="100" />
            <h2>Maquillaje Compacto 2 en 1</h2>
            <p>El maquillaje compacto 2 en 1 proporciona un acabado cremoso tipo base, que se obtiene al humedecer la esponja incluida.</p>
            <p>Precio: $420</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Maquillaje Compacto 2 en 1">
                <input type="hidden" name="precio" value="420">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            
            <div class="producto">
            <img src="imagenes/liquido.jpg"width="100" height="100" />
            <h2>Maquillaje Líquido UP+ FPS15 </h2>
            <p>Base de maquillaje con acabado mate, de larga duración y cobertura construible, que corregirá el tono de tu piel mientras la protege con sus activos anti edad, humectantes, antioxidantes</p>
            <p>Precio: $490</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Maquillaje Líquido UP+ FPS15 ">
                <input type="hidden" name="precio" value="490">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            <div class="producto">
            <img src="imagenes/brillo.jpg"width="100" height="100" />
            <h2>Brillo Labial</h2>
            <p>La nueva fórmula de los Brillos de Seytú se funde sobre los labios proporcionando un inigualable brillo con efecto voluminizador, en una increíble gama de colores para tus labios.</p>
            <p>Precio: $305</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Brillo Labial">
                <input type="hidden" name="precio" value="350">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            <div class="producto">
            <img src="imagenes/labial.jpg"width="100" height="100" />
            <h2>Labial Hidratante FPS 15 </h2>
            <p>una gama de tonos imprescindibles que harán deslumbrar tus labios en cualquier ocasión. Su fórmula es la combinación perfecta entre textura ultra cremosa y colores intensos de larga duración.</p>
            <p>Precio: $225</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Labial Hidratante FPS 15">
                <input type="hidden" name="precio" value="225">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div>
            <div class="producto">
            <img src="imagenes/mate.jpg"width="100" height="100" />
            <h2>Labial Líquido Mate </h2>
            <p>Labial líquido de suave aplicación que proporciona un color intenso. Su acabado mate brinda un terminado sofisticado a los labios.</p>
            <p>Precio: $315</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Labial Líquido Mate">
                <input type="hidden" name="precio" value="315">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div> 
            <div class="producto">
            <img src="imagenes/delineador.jpg"width="100" height="100" />
            <h2>Lápiz Delineador de Ojos</h2>
            <p>Con el lápiz delineador de ojos de SEYTÚ crearás miradas radiantes y expresivas con líneas precisas o efecto ahumado.</p>
            <p>Precio: $235</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Lápiz Delineador de Ojos">
                <input type="hidden" name="precio" value="235">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div> 
        
            <div class="producto">
            <img src="imagenes/mascara.jpg"width="100" height="100" />
            <h2>Máscara para Pestañas</h2>
            <p>Máscara de máximo alargamiento y volumen; con innovador cepillo esférico, especialmente diseñado para una aplicación precisa, que riza y separa las pestañas a la perfección sin dejar grumos.</p>
            <p>Precio: $275</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Máscara para Pestañas">
                <input type="hidden" name="precio" value="275">
                <button type="submit">agregar al carrito</button>
            </form>    
            
            </div> 
            <div class="producto">
            <img src="imagenes/marrones.jpg"width="100" height="100" />
            <h2>Paleta de Sombras Marrones</h2>
            <p>Polvo fino compacto, con textura suave y cremosa ideada para darle profundidad, elegancia, brillo y color a tu mirada.</p>
            <p>Precio: $610</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Paleta de Sombras Marrones">
                <input type="hidden" name="precio" value="610">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div> 
            <div class="producto">
            <img src="imagenes/rosas.jpg"width="100" height="100" />
            <h2>Paleta de Sombras Rosas</h2>
            <p>Polvo fino compacto, con textura suave y cremosa ideada para darle profundidad, elegancia, brillo y color a tu mirada.</p>
            <p>Precio: $610</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Paleta de Sombras Rosas">
                <input type="hidden" name="precio" value="610">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div> 
           
            <div class="producto">
            <img src="imagenes/iluminador.jpg"width="100" height="100" />
            <h2>Polvo Iluminador</h2>
            <p>Polvo iluminador de larga duración, que proporciona un brillo radiante y aterciopelado</p>
            <p>Precio: $215</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Polvo Iluminador">
                <input type="hidden" name="precio" value="215">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div> 
           
            <div class="producto">
            <img src="imagenes/set.jpg"width="100" height="100" />
            <h2>Set Delineador Compacto para Cejas</h2>
            <p>Definición, volumen, color y textura, es lo que les puedes dar con el Set Delineador Compacto para Cejas</p>
            <p>Precio: $425</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Set Delineador Compacto para Cejas">
                <input type="hidden" name="precio" value="425">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div> 
            
            <div class="producto">
            <img src="imagenes/rubor.jpg"width="100" height="100" />
            <h2>Rubor Compacto</h2>
            <p>De textura fina, suave y de alta cobertura, el rubor es de fácil aplicación, adhiriéndose a la piel y asegurando una larga duración.</p>
            <p>Precio: $235</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="producto" value="Rubor Compacto">
                <input type="hidden" name="precio" value="235">
                <button type="submit">agregar al carrito</button>
            </form>    
            </div> 
            
    </div>
</body>
</html>